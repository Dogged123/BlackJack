public class Hand 
{
   //instance variables
   private static int value;
   private static int cardValue;
   private static int cardSuit;
   private static String suit;
   private static String faceCard;
   private static String card;
   private static String newCard = "";
   private static String positive = "positive";
   private static String negative = "negative";
   
   public Hand()
   {
        value = 0;
   }
   
   public int getValue()
    {
        return value;
    }
    
    //addCard
    public String addCard()
    {
        cardSuit = (int)(Math.random()*4 + 1);
        if(cardSuit == 1)
        {
            suit = "♦";
        }
        else if(cardSuit == 2)
        {
            suit = "♥";
        }
        else if(cardSuit == 3)
        {
            suit = "♣";
        }
        else if(cardSuit == 4)
        {
            suit = "♠";
        }
        
        cardValue = (int)(Math.random()*13 + 1);
        if(cardValue == 1)
        {
            faceCard = "A";
            System.out.println(faceCard + suit);
            newCard = faceCard + suit;
            if(value < 11)
            {
                cardValue = 11;
            }
            else cardValue = 1;
        }
        else if(cardValue == 11)
        {
            faceCard = "J";
            cardValue = 10;
            System.out.println(faceCard + suit);
            newCard = faceCard + suit;
        }
        else if(cardValue == 12)
        {
            faceCard = "Q";
            cardValue = 10;
            System.out.println(faceCard + suit);
            newCard = faceCard + suit;
        }
        else if(cardValue == 13)
        {
            faceCard = "K";
            cardValue = 10;
            System.out.println(faceCard + suit);
            newCard = faceCard + suit;
        }
        else System.out.println(cardValue + suit);
        
        newCard = cardValue + suit;
        
        if(!newCard.equals(card))
        {
            card = newCard;
        }
        
        value += cardValue;
        System.out.println("Total Card Value: " + value);
        
        if(value > 21)
        {
            return negative;
        }
        if(value == 21)
        {
            return positive;
        }
        return "";
    }
    
}