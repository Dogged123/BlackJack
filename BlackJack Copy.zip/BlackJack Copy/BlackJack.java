import java.util.*;
public class BlackJack
{
    //instance variables
    private static int money = 100;
    private static int pot = 0;
    private static String garbage;
    private static String replay;
    private static int loan;
    
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        //Greeting
        System.out.println("Hi! Welcome to BlackJack!");
        System.out.println("What is your name?");
        String name = input.nextLine();
        
        while(true)
        {
        pot = 0;
        System.out.print("\033[2J");
        System.out.print("\033[H");
    
        //Objects
        Hand pHand = new Hand();
        Computer cHand = new Computer();
        
        System.out.println("First Card:");
        String pCard = pHand.addCard();
        System.out.println("Second Card:");
        pCard = pHand.addCard();
        
        String cCard = cHand.addCard();
        cCard = cHand.addCard();
        int compVal = cHand.getValue();
        System.out.println("Computer's initial card value: " + compVal);
        
        int handVal = pHand.getValue();
        
        while(true)
        {
            //loan system
            if(money == 0)
            {
                System.out.println("You currently have $0. How much money would you like to borrow from the bank?");
                loan = input.nextInt();
                money += loan;
            }
            
            //betting
            System.out.println("How much would you like to bet? You have $" + money);
            int bet = input.nextInt();
            while(bet > money)
            {
                System.out.println("You do not have that kind of money!");
                System.out.println("How much would you like to bet? You have $" + money + ".00");
                bet = input.nextInt();
            }
            while(bet < 0)
            {
                System.out.println("You cannot bet $-! That's stealing!!! GET OUT OF THE CASINO NOW!");
                System.exit(0);
            }
            
            money -= bet;
            pot += bet*2;
            
            System.out.println("The computer matched your bet so the current pot is $" + pot);
            
            //new card loop
            System.out.println("Do you want another card? (Y/N)");
            garbage = input.nextLine();
            String choice = input.nextLine();
            choice = choice.toLowerCase();
            if(choice.substring(0,1).equals("y"))
            {
                System.out.print("\033[2J");
                System.out.print("\033[H");
                pCard = pHand.addCard();
                compVal = cHand.getValue();
                if(compVal < 17)
                {
                    cCard = cHand.addCard();
                }
                
                compVal = cHand.getValue();
                handVal = pHand.getValue();
                System.out.println("Value of Computer's Hand: " + compVal);
                
                if (cCard.equals("positive") || pCard.equals("positive")) 
                {
                    System.out.println("Your points: " + handVal + ", Computer points: " + compVal);
                    System.out.println(name + " WINS!");
                    System.out.println("You won $" + pot + "!!!");
                    if(loan > 0)
                    {
                        int loanBack = (pot - loan);
                        System.out.println("Because you had a loan of $" + loan + ", you only won $" + loanBack);
                    }
                    money += (pot - loan);
                    System.out.println("Do you want to play again? Y/N");
                    replay = input.nextLine();
                    replay = replay.toLowerCase();
                    if(replay.substring(0,1).equals("y"))
                    {
                        break;
                    }
                    else System.exit(0);
                }
                
                //winner check
                else if(cCard.equals("negative") || pCard.equals("negative"))
                {
                    System.out.println("Computer points: " + compVal + ",Your points: " + handVal);
                    System.out.println("YOU LOSE! This should teach you not to gamble underage!");
                    System.out.println("You lost $" + (pot/2) + "...");
                    System.out.println("Do you want to play again? Y/N");
                    replay = input.nextLine();
                    replay = replay.toLowerCase();
                    if(replay.substring(0,1).equals("y"))
                    {
                        break; 
                    }
                    else System.exit(0);
                }
            }
            else if(choice.substring(0,1).equals("n"))
            {
                System.out.print("\033[2J");
                System.out.print("\033[H");
                handVal = pHand.getValue();
                compVal = cHand.getValue();
                
                while(compVal < 17)
                {
                    cCard = cHand.addCard();
                    System.out.println("Computer drew a card");
                    compVal = cHand.getValue();
                    System.out.println("Value of Computer's Hand: " + compVal);
                }
                if(compVal > 21)
                {
                    System.out.println("Your points: " + handVal + ", Computer points: " + compVal);
                    System.out.println(name + " WINS!");
                    System.out.println("You won $" + pot + "!!!");
                    if(loan > 0)
                    {
                        int loanBack = (int)(pot - loan);
                        System.out.println("Because you had a loan of $" + loan + ", you only won $" + loanBack);
                    }
                    money += (pot - loan);
                    System.out.println("Do you want to play again? Y/N");
                    replay = input.nextLine();
                    replay = replay.toLowerCase();
                    if(replay.substring(0,1).equals("y"))
                    {
                        break; 
                    }
                    else System.exit(0);
                    
                }
                
                if(handVal > compVal)
                {
                    handVal = pHand.getValue();
                    System.out.println("Your points: " + handVal + ", Computer points: " + compVal);
                    System.out.println(name + " WINS!");
                    System.out.println("You won $" + pot + "!!!");
                    if(loan > 0)
                    {
                        int loanBack = (pot - loan);
                        System.out.println("Because you had a loan of $" + loan + ", you only won $" + loanBack);
                    }
                    money += (pot - loan);
                    System.out.println("Do you want to play again? Y/N");
                    replay = input.nextLine();
                    replay = replay.toLowerCase();
                    if(replay.equals("y"))
                    {
                        break; 
                    }
                    else System.exit(0);
                }
                else 
                System.out.println("Computer points: " + compVal + ", Your points: " + handVal);
                System.out.println("YOU LOSE! This should teach you not to gamble underage!");
                System.out.println("You lost $" + (pot/2) + "...");
                System.out.println("Do you want to play again? Y/N");
                replay = input.nextLine();
                replay = replay.toLowerCase();
                if(replay.substring(0,1).equals("y"))
                {
                    break; 
                }
                else System.exit(0);
            }
            
        } 
        }
        
    }
}