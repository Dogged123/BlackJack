public class Computer 
{
    private static int value;
    private static int cardValue;
    private static int cardSuit;
    private static String suit;
    private static String positive = "positive";
    private static String negative = "negative";

    
    public Computer()
    {
        value = 0;
    }
    
    public int getValue()
    {
        return value;
    }
    
    public String addCard()
    {
        cardValue = (int)(Math.random()*13 + 1);
        if(cardValue == 1)
        {
            if(value < 11)
            {
                cardValue = 11;
            }
            else cardValue = 1;
        }
        else if (cardValue == 11)
        {
            cardValue = 10;
        }
        else if (cardValue == 12)
        {
            cardValue = 10;
        }
        else if (cardValue == 13)
        {
            cardValue = 10;
        }
        cardSuit = (int)(Math.random()*4 + 1);
        if(cardSuit == 1)
        {
            suit = "♦";
        }
        else if(cardSuit == 2)
        {
            suit = "♥";
        }
        else if(cardSuit == 3)
        {
            suit = "♣";
        }
        else if(cardSuit == 4)
        {
            suit = "♠";
        }

        value += cardValue;
        
        if(value > 21)
        {
            return positive;
        }
        if(value == 21)
        {
            return negative;
        }
        else return "";
    }
}